import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence, useScroll } from 'motion/react';
import { Menu, X, Star, ChevronRight, Phone, Mail, MapPin, Instagram, Facebook } from 'lucide-react';
import { ExpandableText } from './components/ExpandableText';
import { Carousel } from './components/Carousel';
import { Reviews } from './components/Reviews';

const TREATMENTS = [
  { id: '1', title: 'Baby', image: 'https://picsum.photos/seed/baby/800/1200', link: '#' },
  { id: '2', title: 'Sport', image: 'https://picsum.photos/seed/sport/800/1200', link: '#' },
  { id: '3', title: 'Kæbe', image: 'https://picsum.photos/seed/jaw/800/1200', link: '#' },
  { id: '4', title: 'Nakke', image: 'https://picsum.photos/seed/neck/800/1200', link: '#' },
  { id: '5', title: 'Ryg', image: 'https://picsum.photos/seed/back/800/1200', link: '#' },
  { id: '6', title: 'Bækken', image: 'https://picsum.photos/seed/pelvis/800/1200', link: '#' },
];

const LOCATIONS = [
  { id: '1', title: 'Aalborg', image: 'https://picsum.photos/seed/aalborg/800/1200', link: '#' },
  { id: '2', title: 'Aarhus', image: 'https://picsum.photos/seed/aarhus/800/1200', link: '#' },
  { id: '3', title: 'Hjørring', image: 'https://picsum.photos/seed/hjorring/800/1200', link: '#' },
  { id: '4', title: 'Silkeborg', image: 'https://picsum.photos/seed/silkeborg/800/1200', link: '#' },
];

const ARTICLES = [
  { id: '1', title: 'Rygsmerter som ikke vil forsvinde? Osteopati som løsning', image: 'https://picsum.photos/seed/art1/800/600' },
  { id: '2', title: 'Osteoporose – det skal da belastes?', image: 'https://picsum.photos/seed/art2/800/600' },
  { id: '3', title: 'Forstoppelse under graviditet: Årsager og behandling', image: 'https://picsum.photos/seed/art3/800/600' },
];

export default function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const { scrollY } = useScroll();
  
  useEffect(() => {
    const unsubscribe = scrollY.on('change', (latest) => {
      setIsScrolled(latest > 50);
    });
    return () => unsubscribe();
  }, [scrollY]);

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-white/90 backdrop-blur-md shadow-sm py-4' : 'bg-transparent py-6'}`}>
        <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-brand-primary rounded-full flex items-center justify-center">
                <div className="w-6 h-6 border-2 border-white rounded-full flex items-center justify-center">
                  <div className="w-2 h-2 bg-white rounded-full" />
                </div>
              </div>
              <span className={`text-xl font-bold tracking-tight ${isScrolled ? 'text-charcoal' : 'text-white'}`}>
                Aktiv Fysioterapi
              </span>
            </div>
          </div>

          <div className="hidden md:flex items-center gap-8">
            {['Forside', 'Behandlinger', 'Afdelinger', 'Blog', 'Kontakt'].map((item) => (
              <a 
                key={item} 
                href="#" 
                className={`text-sm font-medium hover:opacity-70 transition-opacity ${isScrolled ? 'text-charcoal' : 'text-white'}`}
              >
                {item}
              </a>
            ))}
            <button className="bg-brand-secondary text-white px-6 py-2.5 rounded-full text-sm font-bold hover:opacity-90 transition-opacity">
              Book tid
            </button>
            <button className={`px-6 py-2.5 rounded-full text-sm font-bold transition-all ${isScrolled ? 'bg-brand-primary/10 text-brand-primary' : 'bg-white/20 backdrop-blur-md text-white border border-white/30 hover:bg-white/30'}`}>
              Gratis screening
            </button>
          </div>

          <button 
            className="md:hidden p-2"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className={isScrolled ? 'text-charcoal' : 'text-white'} /> : <Menu className={isScrolled ? 'text-charcoal' : 'text-white'} />}
          </button>
        </div>
      </nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-0 bg-white z-40 pt-24 px-6 md:hidden"
          >
            <div className="flex flex-col gap-6">
              {['Forside', 'Behandlinger', 'Afdelinger', 'Blog', 'Kontakt'].map((item) => (
                <a key={item} href="#" className="text-2xl font-bold text-charcoal">{item}</a>
              ))}
              <div className="flex flex-col gap-4 pt-6">
                <button className="w-full bg-brand-secondary text-white py-4 rounded-xl font-bold">Book tid</button>
                <button className="w-full bg-brand-primary text-white py-4 rounded-xl font-bold">Gratis screening</button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Hero Section */}
      <section className="relative h-screen w-full overflow-hidden bg-charcoal">
        <div className="absolute inset-0 w-full h-full">
          <div className="absolute inset-0 bg-black/40 z-10" />
          <img 
            src="https://picsum.photos/seed/physio/1920/1080?blur=2" 
            className="w-full h-full object-cover"
            alt="Hero Background"
            referrerPolicy="no-referrer"
          />
        </div>

        <div className="relative z-20 h-full max-w-7xl mx-auto px-6 flex flex-col justify-center items-start">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-2xl"
          >
            <span className="inline-block text-brand-primary font-bold tracking-widest uppercase text-sm mb-4">
              Velkommen til Aktiv Fysioterapi
            </span>
            <h1 className="text-5xl md:text-7xl text-white font-bold leading-[1.1] mb-8">
              Helhedsorienteret behandling med fokus på dig
            </h1>
            
            <div className="flex items-center gap-4 mb-12">
              <div className="flex gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} size={20} className="fill-brand-secondary text-brand-secondary" />
                ))}
              </div>
              <span className="text-white/80 font-medium">Google anmeldelser</span>
            </div>

            <div className="bg-white/10 backdrop-blur-lg border border-white/20 p-8 rounded-3xl mb-12">
              <ExpandableText 
                text="Ofte findes årsagen til smerteproblematikker et helt andet sted end der, hvor symptomerne opleves. Hos Aktiv Fysioterapi vil vi igennem spørgsmål, og grundig undersøgelse af kroppens systemer, finde årsagen til dine symptomer, for herefter at yde højkvalitetsbehandling baseret på de osteopatiske grundprincipper."
              />
            </div>

            <div className="flex flex-wrap gap-4">
              <button className="bg-brand-secondary text-white px-10 py-4 rounded-full font-bold text-lg hover:scale-105 transition-transform">
                Book tid nu
              </button>
              <button className="bg-white text-charcoal px-10 py-4 rounded-full font-bold text-lg hover:scale-105 transition-transform">
                Gratis screening
              </button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Treatments Section */}
      <section className="section-padding bg-frosted-mint/30">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-6">
            <div className="max-w-xl">
              <h2 className="text-4xl md:text-5xl font-bold mb-6">Behandlinger</h2>
              <p className="text-lg text-charcoal/70">
                Vi tilbyder en bred vifte af specialiserede behandlinger tilpasset dine unikke behov og udfordringer.
              </p>
            </div>
            <a href="#" className="flex items-center gap-2 text-brand-secondary font-bold hover:gap-4 transition-all">
              Se alle behandlinger <ChevronRight size={20} />
            </a>
          </div>
          <Carousel items={TREATMENTS} />
        </div>
      </section>

      {/* Trust Section */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="relative rounded-3xl overflow-hidden aspect-[4/5]">
              <img 
                src="https://picsum.photos/seed/clinic/1200/1500" 
                alt="Vores Klinik" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
              <div className="absolute bottom-12 left-12 right-12">
                <div className="bg-white/20 backdrop-blur-xl p-8 rounded-2xl border border-white/30">
                  <h3 className="text-white text-2xl font-bold mb-4">Tryghed & Faglighed</h3>
                  <p className="text-white/90 mb-0">Som klient hos os kan du være sikker på, at vi benytter forsvarlige og velovervejede teknikker.</p>
                </div>
              </div>
            </div>
            
            <div className="element-spacing">
              <div>
                <h2 className="text-4xl md:text-5xl font-bold mb-8">Vi samler på glade klienter</h2>
                <Reviews />
              </div>
              
              <div className="bg-celadon/10 p-10 rounded-3xl border border-celadon/20">
                <h3 className="text-2xl font-bold mb-6">Hvorfor vælge os?</h3>
                <ul className="inner-spacing">
                  {[
                    'Ekspertise: Dygtige og erfarne fagfolk',
                    'Komplet behandlingstilgang: Manuel behandling & træning',
                    'Individuel tilgang: Skræddersyede behandlingsplaner'
                  ].map((item, i) => (
                    <li key={i} className="flex items-start gap-4">
                      <div className="mt-1 w-6 h-6 bg-brand-primary rounded-full flex items-center justify-center flex-shrink-0">
                        <Star size={12} className="text-white fill-white" />
                      </div>
                      <span className="text-lg font-medium text-charcoal/80">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Departments Section */}
      <section className="section-padding bg-charcoal text-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="max-w-2xl mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-8">Vores Afdelinger</h2>
            <p className="text-xl text-white/70">
              Find os i hele landet. Vi har moderne klinikker med det nyeste udstyr og de bedste faciliteter.
            </p>
          </div>
          <Carousel items={LOCATIONS} />
        </div>
      </section>

      {/* Free Screening CTA */}
      <section className="section-padding bg-brand-primary/10">
        <div className="max-w-7xl mx-auto px-6">
          <div className="bg-white rounded-[40px] overflow-hidden shadow-xl border border-black/5 flex flex-col md:flex-row">
            <div className="flex-1 p-12 md:p-20 flex flex-col justify-center">
              <h2 className="text-4xl md:text-5xl font-bold mb-8">Er du i tvivl? Få en gratis screening</h2>
              <p className="text-xl text-charcoal/70 mb-12">
                Beskriv dine symptomer, og vi kontakter dig hurtigst muligt for en uforpligtende snak om dine behov og behandlingsmuligheder.
              </p>
              <button className="bg-brand-secondary text-white px-12 py-5 rounded-full font-bold text-xl hover:scale-105 transition-transform self-start">
                Få en gratis screening her
              </button>
            </div>
            <div className="flex-1 h-[400px] md:h-auto">
              <img 
                src="https://picsum.photos/seed/screening/1000/1200" 
                alt="Screening" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Blog Section */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex justify-between items-end mb-16">
            <h2 className="text-4xl md:text-5xl font-bold">Seneste Artikler</h2>
            <a href="#" className="text-brand-secondary font-bold hover:underline">Se alle artikler</a>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {ARTICLES.map((article) => (
              <motion.article 
                key={article.id}
                whileHover={{ y: -10 }}
                className="group cursor-pointer"
              >
                <div className="aspect-video rounded-2xl overflow-hidden mb-6">
                  <img 
                    src={article.image} 
                    alt={article.title} 
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <h3 className="text-2xl font-bold group-hover:text-brand-secondary transition-colors">
                  {article.title}
                </h3>
              </motion.article>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-charcoal text-white pt-24 pb-12">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-16 mb-24">
            <div className="element-spacing">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-brand-primary rounded-full flex items-center justify-center">
                  <div className="w-6 h-6 border-2 border-white rounded-full flex items-center justify-center">
                    <div className="w-2 h-2 bg-white rounded-full" />
                  </div>
                </div>
                <span className="text-2xl font-bold tracking-tight">Aktiv Fysioterapi</span>
              </div>
              <p className="text-white/60">
                Vi ønsker at være din foretrukne sparringspartner når det kommer til din sundhed og velvære.
              </p>
              <div className="flex gap-4">
                <a href="#" className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-brand-primary transition-colors">
                  <Facebook size={20} />
                </a>
                <a href="#" className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-brand-primary transition-colors">
                  <Instagram size={20} />
                </a>
              </div>
            </div>

            <div>
              <h4 className="text-xl font-bold mb-8">Kontakt</h4>
              <ul className="space-y-6 text-white/60">
                <li className="flex items-center gap-4">
                  <Phone size={20} className="text-brand-primary" />
                  <span>+45 88 88 80 80</span>
                </li>
                <li className="flex items-center gap-4">
                  <Mail size={20} className="text-brand-primary" />
                  <span>kontakt@aktivfys.dk</span>
                </li>
                <li className="flex items-start gap-4">
                  <MapPin size={20} className="text-brand-primary mt-1" />
                  <span>Skelagervej 375A,<br />9000 Aalborg</span>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-xl font-bold mb-8">Åbningstider</h4>
              <ul className="space-y-4 text-white/60">
                <li className="flex justify-between">
                  <span>Mandag - Torsdag</span>
                  <span>08:00 - 16:00</span>
                </li>
                <li className="flex justify-between">
                  <span>Fredag</span>
                  <span>08:00 - 14:00</span>
                </li>
                <li className="flex justify-between">
                  <span>Lørdag - Søndag</span>
                  <span>Lukket</span>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-xl font-bold mb-8">Genveje</h4>
              <ul className="space-y-4 text-white/60">
                {['Priser', 'Om os', 'Ledige stillinger', 'Privatlivspolitik', 'Cookiepolitik'].map((item) => (
                  <li key={item}>
                    <a href="#" className="hover:text-brand-primary transition-colors">{item}</a>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="pt-12 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-6">
            <p className="text-white/40 text-sm">
              © {new Date().getFullYear()} Aktiv Fysioterapi. Alle rettigheder forbeholdes.
            </p>
            <div className="flex items-center gap-8">
              <img 
                src="https://osteodanmark.dk/wp-content/uploads/2022/03/Danske_osteopater_logo_rund.png" 
                alt="Danske Osteopater" 
                className="h-12 opacity-50 hover:opacity-100 transition-opacity"
              />
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
