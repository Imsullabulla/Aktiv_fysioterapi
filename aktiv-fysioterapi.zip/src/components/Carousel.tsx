import React from 'react';
import { motion } from 'motion/react';

interface CarouselItem {
  id: string;
  title: string;
  image: string;
  link: string;
}

interface CarouselProps {
  items: CarouselItem[];
}

export const Carousel: React.FC<CarouselProps> = ({ items }) => {
  return (
    <div className="relative w-full overflow-hidden">
      <div className="flex gap-6 overflow-x-auto no-scrollbar pb-8 px-4 md:px-0 snap-x">
        {items.map((item) => (
          <motion.a
            key={item.id}
            href={item.link}
            whileHover={{ scale: 1.02 }}
            className="flex-none w-[280px] md:w-[350px] aspect-[3/4] relative rounded-2xl overflow-hidden snap-start group"
          >
            <img 
              src={item.image} 
              alt={item.title}
              className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
            <div className="absolute bottom-0 left-0 p-6 w-full">
              <h3 className="text-white text-2xl font-bold mb-2">{item.title}</h3>
              <span className="inline-block px-4 py-2 bg-white/20 backdrop-blur-md text-white rounded-full text-sm font-medium border border-white/30">
                Læs mere
              </span>
            </div>
          </motion.a>
        ))}
      </div>
    </div>
  );
};
