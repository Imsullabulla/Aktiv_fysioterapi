import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface ExpandableTextProps {
  text: string;
  maxWords?: number;
}

export const ExpandableText: React.FC<ExpandableTextProps> = ({ text, maxWords = 40 }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  
  const words = text.split(' ');
  const shouldTruncate = words.length > maxWords;
  
  const displayText = isExpanded || !shouldTruncate 
    ? text 
    : words.slice(0, maxWords).join(' ') + '...';

  return (
    <div className="relative">
      <motion.div 
        layout
        className="text-lg text-charcoal/80 leading-relaxed"
      >
        {displayText}
      </motion.div>
      
      {shouldTruncate && (
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="mt-4 flex items-center gap-2 text-brand-secondary font-semibold hover:opacity-80 transition-opacity"
        >
          {isExpanded ? (
            <>
              <span>Luk</span>
              <ChevronUp size={20} />
            </>
          ) : (
            <>
              <span>Læs mere</span>
              <ChevronDown size={20} />
            </>
          )}
        </button>
      )}
    </div>
  );
};
